using UnityEngine;

public class PunchHitboxController : MonoBehaviour
{
    [Header("Damage Settings")]
    [Tooltip("Max damage if the opponent is near the center of the punch.")]
    public float maxDamage = 10f;
    [Tooltip("Min damage if the opponent is near the edge.")]
    public float minDamage = 5f;

    // Store the original local position (this should be the working position for east-facing punches).
    private Vector3 defaultLocalPosition;
    private Collider2D col;
    private bool isActive = false;

    private void Awake()
    {
        // Record the starting localPosition as our baseline.
        defaultLocalPosition = transform.localPosition;
        
        col = GetComponent<Collider2D>();
        if (col != null)
        {
            col.isTrigger = true;
            col.enabled = false; // start off disabled
        }
    }

    private void Update()
    {
        // Determine facing.
        // First, try using the parent's SpriteRenderer.flipX if available.
        bool facingRight = true;
        SpriteRenderer sr = transform.parent.GetComponent<SpriteRenderer>();
        if (sr != null)
        {
            // Assume that when flipX is false, character is facing right.
            facingRight = !sr.flipX;
        }
        else
        {
            // Fallback: try using the state machine's public property.
            var ps = transform.parent.GetComponent<PlayerStateMachine>();
            if (ps != null)
                facingRight = ps.IsFacingRight;
            else
            {
                var es = transform.parent.GetComponent<EnemyStateMachine>();
                if (es != null)
                    facingRight = es.IsFacingRight;
            }
        }

        // Set localPosition: if facing right, use default; if not, mirror the x value.
        if (facingRight)
        {
            transform.localPosition = new Vector3(Mathf.Abs(defaultLocalPosition.x),
                                                  defaultLocalPosition.y,
                                                  defaultLocalPosition.z);
        }
        else
        {
            transform.localPosition = new Vector3(-Mathf.Abs(defaultLocalPosition.x),
                                                  defaultLocalPosition.y,
                                                  defaultLocalPosition.z);
        }
    }

    public void ActivateHitbox()
    {
        if (col == null)
            return;
        col.enabled = true;
        isActive = true;
        Debug.Log($"[PunchHitboxController] {name} => Hitbox ACTIVATED at {Time.time} (Global pos: {transform.position})");
    }

    public void DeactivateHitbox()
    {
        if (col == null)
            return;
        col.enabled = false;
        isActive = false;
        Debug.Log($"[PunchHitboxController] {name} => Hitbox DEACTIVATED at {Time.time}");
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log($"[PunchHitboxController] {name} OnTriggerEnter2D with {other.name}");
        if (!isActive)
            return;
        if (other.gameObject == transform.parent.gameObject)
            return; // ignore self

        // Calculate damage based on distance from the hitbox's collider center.
        float damage = CalculateDamage(other.bounds.center);

        // Check if the target is a Player.
        var targetPlayer = other.GetComponent<PlayerStateMachine>();
        if (targetPlayer != null)
        {
            targetPlayer.TakeHit(transform.parent.position, damage);
            return;
        }
        // Check if the target is an Enemy.
        var targetEnemy = other.GetComponent<EnemyStateMachine>();
        if (targetEnemy != null)
        {
            targetEnemy.TakeHit(transform.parent.position, damage);
            return;
        }
    }

    private float CalculateDamage(Vector3 opponentCenter)
    {
        if (col is CircleCollider2D circleCol)
        {
            float radius = circleCol.radius * Mathf.Abs(transform.lossyScale.x);
            float dist = Vector2.Distance(opponentCenter, circleCol.bounds.center);
            float t = Mathf.InverseLerp(radius, 0f, dist);
            return Mathf.Lerp(minDamage, maxDamage, t);
        }
        else if (col is BoxCollider2D boxCol)
        {
            Vector2 halfSize = boxCol.size * 0.5f * transform.lossyScale;
            float maxDist = halfSize.magnitude;
            float dist = Vector2.Distance(opponentCenter, boxCol.bounds.center);
            float t = Mathf.InverseLerp(maxDist, 0f, dist);
            return Mathf.Lerp(minDamage, maxDamage, t);
        }
        return (maxDamage + minDamage) * 0.5f;
    }

    private void OnDrawGizmos()
    {
        if (col != null && col.enabled)
        {
            Gizmos.color = Color.red;
            if (col is CircleCollider2D circle)
            {
                float radius = circle.radius * Mathf.Abs(transform.lossyScale.x);
                Gizmos.DrawWireSphere(circle.bounds.center, radius);
            }
            else if (col is BoxCollider2D box)
            {
                Gizmos.DrawWireCube(box.bounds.center, box.bounds.size);
            }
        }
    }
}