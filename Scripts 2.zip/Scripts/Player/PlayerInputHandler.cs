using UnityEngine;

public class PlayerInputHandler : MonoBehaviour
{
    [Header("Movement")]
    public bool allowDiagonalMovement = true;

    private Vector2 _movement;
    public Vector2 MovementInput => _movement;

    public bool PunchPressed { get; private set; }
    public bool BlockPressed { get; private set; }

    [Tooltip("Keys for Punch (e.g., Space, J)")]
    public KeyCode[] punchKeys = { KeyCode.Space, KeyCode.J };
    [Tooltip("Key for Block (e.g., B)")]
    public KeyCode blockKey = KeyCode.B;

    private void Update()
    {
        _movement = Vector2.zero;
        PunchPressed = false;
        BlockPressed = false;

        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");
        _movement.x += horizontal;
        _movement.y += vertical;

        if (!allowDiagonalMovement)
        {
            // remove weaker axis if diagonal
            if (Mathf.Abs(_movement.x) > Mathf.Abs(_movement.y))
                _movement.y = 0f;
            else
                _movement.x = 0f;
        }

        if (_movement.magnitude > 1f)
            _movement = _movement.normalized;

        // Punch
        if (AnyKeyDown(punchKeys))
            PunchPressed = true;

        // Block
        if (Input.GetKeyDown(blockKey))
            BlockPressed = true;
    }

    private bool AnyKeyDown(KeyCode[] keys)
    {
        foreach (var k in keys)
        {
            if (Input.GetKeyDown(k))
                return true;
        }
        return false;
    }
}