using UnityEngine;

[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(SpriteRenderer))]
public class PlayerAnimationController : MonoBehaviour
{
    public string idleStateName = "Idle";
    public string walkStateName = "Walk";
    public string punchStateName = "Punch";
    public string blockStateName = "Block";
    public string getHitStateName = "GetHit";
    public string recoveryStateName = "Recovery";

    private Animator animator;
    private SpriteRenderer spriteRenderer;
    private string currentAnimation;

    private void Awake()
    {
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void UpdateAnimation(PlayerCombatState state, bool facingRight)
    {
        // Flip the sprite
        spriteRenderer.flipX = !facingRight;

        string animToPlay = idleStateName;
        switch (state)
        {
            case PlayerCombatState.Walking:
                animToPlay = walkStateName;
                break;
            case PlayerCombatState.Punching:
                animToPlay = punchStateName;
                break;
            case PlayerCombatState.Blocking:
                animToPlay = blockStateName;
                break;
            case PlayerCombatState.GetHit:
                animToPlay = getHitStateName;
                break;
            case PlayerCombatState.Recovery:
                animToPlay = recoveryStateName;
                break;
            default:
                animToPlay = idleStateName;
                break;
        }

        if (currentAnimation != animToPlay)
        {
            animator.Play(animToPlay);
            currentAnimation = animToPlay;
        }
    }
}