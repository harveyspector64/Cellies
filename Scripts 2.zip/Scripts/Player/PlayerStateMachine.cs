using UnityEngine;

public enum PlayerCombatState
{
    Idle,
    Walking,
    Punching,
    Blocking,
    GetHit,
    Recovery
}

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(PlayerInputHandler))]
[RequireComponent(typeof(PlayerAnimationController))]
public class PlayerStateMachine : MonoBehaviour
{
    [Header("Movement")]
    public float baseMoveSpeed = 3f;
    public float punchingSpeedPenalty = 1.5f;
    public float spamPenalty = 2f;

    [Header("Punch Settings")]
    public float punchDuration = 0.3f;
    public float basePunchCooldown = 0.2f;
    public int maxConsecutivePunches = 3;
    public float extendedRecovery = 1.0f;

    [Header("Hit / Invincibility")]
    public float knockbackForce = 2f;
    public float invulDuration = 0.5f;
    public float hitStunTime = 0.25f; // Duration of the "wobble" effect

    [Header("Block Settings")]
    public float blockDuration = 0.5f;
    public float perfectBlockWindow = 0.2f;

    private Rigidbody2D rb;
    private PlayerInputHandler input;
    private PlayerAnimationController anim;

    private PlayerCombatState currentState = PlayerCombatState.Idle;
    private Vector2 moveVector;
    private bool facingRight = true;
    // Expose a public read-only property for facingRight.
    public bool IsFacingRight => facingRight;

    private float punchTimer = 0f;
    private float punchCooldownTimer = 0f;
    private int consecutivePunches = 0;
    private float recoveryTimer = 0f;

    private bool isInvulnerable = false;
    private float invulTimer = 0f;
    private float getHitTimer = 0f;
    private float blockTimer = 0f;

    [Header("References")]
    [Tooltip("Child object with PunchHitboxController (the pivot).")]
    public PunchHitboxController punchHitboxPivot;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        input = GetComponent<PlayerInputHandler>();
        anim = GetComponent<PlayerAnimationController>();

        rb.gravityScale = 0f;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
    }

    private void Update()
    {
        // Update timers.
        if (punchCooldownTimer > 0f)
            punchCooldownTimer -= Time.deltaTime;
        if (invulTimer > 0f)
        {
            invulTimer -= Time.deltaTime;
            if (invulTimer <= 0f)
                isInvulnerable = false;
        }

        // Handle state-specific behavior.
        switch (currentState)
        {
            case PlayerCombatState.GetHit:
                HandleGetHitState();
                break;
            case PlayerCombatState.Punching:
                HandlePunchState();
                break;
            case PlayerCombatState.Blocking:
                HandleBlockState();
                break;
            case PlayerCombatState.Recovery:
                HandleRecoveryState();
                break;
            default:
                HandleIdleOrWalk();
                break;
        }

        // Flip the hitbox pivot based on facing direction.
        if (punchHitboxPivot != null)
        {
            Vector3 localScale = punchHitboxPivot.transform.localScale;
            localScale.x = facingRight ? Mathf.Abs(localScale.x) : -Mathf.Abs(localScale.x);
            punchHitboxPivot.transform.localScale = localScale;
        }

        anim.UpdateAnimation(currentState, facingRight);
    }

    private void FixedUpdate()
    {
        if (currentState == PlayerCombatState.Idle || currentState == PlayerCombatState.Walking)
            rb.velocity = moveVector * baseMoveSpeed;
        else if (currentState == PlayerCombatState.Punching)
        {
            float penalty = (consecutivePunches > 1) ? spamPenalty : punchingSpeedPenalty;
            rb.velocity = moveVector * (baseMoveSpeed / penalty);
        }
        else
            rb.velocity = Vector2.zero;
    }

    private void HandleIdleOrWalk()
    {
        moveVector = input.MovementInput;
        if (moveVector.x > 0.01f)
            facingRight = true;
        else if (moveVector.x < -0.01f)
            facingRight = false;

        currentState = (moveVector.sqrMagnitude > 0.01f) ? PlayerCombatState.Walking : PlayerCombatState.Idle;

        if (input.PunchPressed && punchCooldownTimer <= 0f)
            StartPunch();

        if (input.BlockPressed)
            StartBlock();
    }

    private void HandlePunchState()
    {
        punchTimer -= Time.deltaTime;
        if (punchTimer <= 0f)
            EndPunch();
    }

    private void HandleBlockState()
    {
        blockTimer -= Time.deltaTime;
        if (blockTimer <= 0f)
            currentState = PlayerCombatState.Idle;
    }

    private void HandleGetHitState()
    {
        getHitTimer -= Time.deltaTime;
        if (getHitTimer <= 0f)
        {
            currentState = PlayerCombatState.Recovery;
            recoveryTimer = 0.3f;
        }
    }

    private void HandleRecoveryState()
    {
        recoveryTimer -= Time.deltaTime;
        if (recoveryTimer <= 0f)
        {
            consecutivePunches = 0;
            currentState = PlayerCombatState.Idle;
        }
    }

    private void StartPunch()
    {
        currentState = PlayerCombatState.Punching;
        punchTimer = punchDuration;
        consecutivePunches++;
        anim.UpdateAnimation(currentState, facingRight);
        // Hitbox activation is handled via animation events.
    }

    private void EndPunch()
    {
        currentState = PlayerCombatState.Recovery;
        OnPunchHitboxDeactivate();
        if (consecutivePunches >= maxConsecutivePunches)
        {
            punchCooldownTimer = extendedRecovery;
            recoveryTimer = extendedRecovery;
            consecutivePunches = 0;
        }
        else
        {
            punchCooldownTimer = basePunchCooldown + (0.05f * consecutivePunches);
            recoveryTimer = 0.2f;
        }
    }

    // --- Public Methods for Animation Events ---

    public void OnPunchHitboxActivate()
    {
        if (punchHitboxPivot != null)
            punchHitboxPivot.ActivateHitbox();
    }

    public void OnPunchHitboxDeactivate()
    {
        if (punchHitboxPivot != null)
            punchHitboxPivot.DeactivateHitbox();
    }

    public void TakeHit(Vector3 attackerPos, float damage)
    {
        // If in recovery, ignore new hits.
        if (currentState == PlayerCombatState.Recovery)
        {
            Debug.Log("Player in recovery; hit ignored.");
            return;
        }
        // If already in hit-stun, chain the hit.
        if (currentState == PlayerCombatState.GetHit)
        {
            getHitTimer = hitStunTime;
            Debug.Log("Player chained hit!");
            return;
        }
        if (currentState == PlayerCombatState.Punching && punchHitboxPivot != null)
            punchHitboxPivot.DeactivateHitbox();

        currentState = PlayerCombatState.GetHit;
        getHitTimer = hitStunTime;
        isInvulnerable = true;
        invulTimer = invulDuration;

        Vector2 knockDir = (transform.position - attackerPos).normalized;
        rb.AddForce(knockDir * knockbackForce, ForceMode2D.Impulse);

        consecutivePunches = 0;
        Debug.Log($"Player took {damage} damage!");
    }

    private void StartBlock()
    {
        if (currentState == PlayerCombatState.Punching || currentState == PlayerCombatState.GetHit)
            return;

        currentState = PlayerCombatState.Blocking;
        blockTimer = blockDuration;
    }
}