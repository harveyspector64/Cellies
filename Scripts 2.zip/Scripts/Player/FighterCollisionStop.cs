using UnityEngine;

/// <summary>
/// This script reduces the component of a fighter's velocity that is pushing it into another fighter,
/// helping them stop sliding into each other. Attach it to any GameObject that represents a fighter's body.
/// Ensure that both fighters have colliders (non-trigger) and a Rigidbody2D.
/// Also, tag your fighter GameObjects with the "Fighter" tag for this to work.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class FighterCollisionStop : MonoBehaviour
{
    private Rigidbody2D rb;

    // Stores the average collision normal from contact points
    private Vector2 collisionNormal = Vector2.zero;
    private bool colliding = false;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        // Optional: Ensure collision detection is continuous if needed
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Fighter"))
        {
            // Get the collision normal from the first contact point.
            collisionNormal = collision.contacts[0].normal;
            colliding = true;
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Fighter"))
        {
            collisionNormal = collision.contacts[0].normal;
            colliding = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Fighter"))
        {
            colliding = false;
            collisionNormal = Vector2.zero;
        }
    }

    private void FixedUpdate()
    {
        if (colliding)
        {
            // Get the current velocity.
            Vector2 currentVelocity = rb.velocity;
            // Project the velocity onto the collision normal.
            float velocityIntoCollision = Vector2.Dot(currentVelocity, collisionNormal);

            // If moving into the collision, subtract that component.
            if (velocityIntoCollision < 0)
            {
                Vector2 adjustment = collisionNormal * velocityIntoCollision;
                rb.velocity = currentVelocity - adjustment;
            }
        }
    }
}