using UnityEngine;
using UnityEngine.Tilemaps;

[System.Serializable]
public struct TileReferences
{
    public TileBase cornerTopLeft, cornerTopRight, cornerBottomLeft, cornerBottomRight;
    public TileBase edgeTop, edgeBottom, edgeLeft, edgeRight;
    public TileBase[] interiorTiles;
}

public class ProceduralMapGenerator : MonoBehaviour
{
    [Header("Configuration")]
    [SerializeField] int mapWidth = 20;
    [SerializeField] int mapHeight = 12;
    [SerializeField] TileReferences tiles;

    [Header("References")]
    [SerializeField] Tilemap tilemap;
    [SerializeField] Grid grid;

    void Start()
    {
        GenerateMap();
    }

    [ContextMenu("Generate Map")]
    public void GenerateMap()
    {
        Debug.Log("Attempting map generation...");
        
        if (!ValidateComponents()) return;
        if (!ValidateTiles()) return;

        tilemap.ClearAllTiles();
        Debug.Log($"Cleared tilemap. Starting generation of {mapWidth}x{mapHeight} map.");

        Vector2Int start = CalculateStartPosition();
        PlaceCorners(start);
        PlaceEdges(start);
        FillInterior(start);

        Debug.Log("Map generation completed. Check Tilemap in Scene view.");
    }

    bool ValidateComponents()
    {
        if (tilemap == null)
        {
            Debug.LogError("Tilemap reference is missing!");
            return false;
        }

        if (grid == null)
        {
            Debug.LogError("Grid reference is missing!");
            return false;
        }

        return true;
    }

    bool ValidateTiles()
    {
        bool valid = true;

        if (tiles.cornerTopLeft == null) { Debug.LogError("Missing Top-Left corner tile!"); valid = false; }
        if (tiles.cornerTopRight == null) { Debug.LogError("Missing Top-Right corner tile!"); valid = false; }
        if (tiles.cornerBottomLeft == null) { Debug.LogError("Missing Bottom-Left corner tile!"); valid = false; }
        if (tiles.cornerBottomRight == null) { Debug.LogError("Missing Bottom-Right corner tile!"); valid = false; }

        if (tiles.edgeTop == null) { Debug.LogError("Missing Top edge tile!"); valid = false; }
        if (tiles.edgeBottom == null) { Debug.LogError("Missing Bottom edge tile!"); valid = false; }
        if (tiles.edgeLeft == null) { Debug.LogError("Missing Left edge tile!"); valid = false; }
        if (tiles.edgeRight == null) { Debug.LogError("Missing Right edge tile!"); valid = false; }

        if (tiles.interiorTiles == null || tiles.interiorTiles.Length == 0)
        {
            Debug.LogError("No interior tiles assigned!");
            valid = false;
        }

        return valid;
    }

    Vector2Int CalculateStartPosition()
    {
        // Calculate bottom-left starting point to center map
        int startX = -mapWidth / 2;
        int startY = -mapHeight / 2;
        Debug.Log($"Map start position: ({startX}, {startY})");
        return new Vector2Int(startX, startY);
    }

    void PlaceCorners(Vector2Int start)
    {
        PlaceTile(start.x, start.y, tiles.cornerBottomLeft);
        PlaceTile(start.x + mapWidth - 1, start.y, tiles.cornerBottomRight);
        PlaceTile(start.x, start.y + mapHeight - 1, tiles.cornerTopLeft);
        PlaceTile(start.x + mapWidth - 1, start.y + mapHeight - 1, tiles.cornerTopRight);
    }

    void PlaceEdges(Vector2Int start)
    {
        // Horizontal edges
        for (int x = 1; x < mapWidth - 1; x++)
        {
            PlaceTile(start.x + x, start.y, tiles.edgeBottom);
            PlaceTile(start.x + x, start.y + mapHeight - 1, tiles.edgeTop);
        }

        // Vertical edges
        for (int y = 1; y < mapHeight - 1; y++)
        {
            PlaceTile(start.x, start.y + y, tiles.edgeLeft);
            PlaceTile(start.x + mapWidth - 1, start.y + y, tiles.edgeRight);
        }
    }

    void FillInterior(Vector2Int start)
    {
        for (int x = 1; x < mapWidth - 1; x++)
        {
            for (int y = 1; y < mapHeight - 1; y++)
            {
                TileBase chosenTile = tiles.interiorTiles[Random.Range(0, tiles.interiorTiles.Length)];
                PlaceTile(start.x + x, start.y + y, chosenTile);
            }
        }
    }

    void PlaceTile(int x, int y, TileBase tile)
    {
        Vector3Int position = new Vector3Int(x, y, 0);
        tilemap.SetTile(position, tile);
    }
}