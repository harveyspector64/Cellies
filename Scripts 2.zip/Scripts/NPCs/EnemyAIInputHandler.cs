using UnityEngine;

public class EnemyAIInputHandler : MonoBehaviour
{
    public Transform targetPlayer;
    public float chaseRange = 5f;
    public float punchRange = 1.2f;
    
    // Instead of a fixed cooldown, use a range.
    public float minPunchCooldown = 0.8f;
    public float maxPunchCooldown = 1.5f;

    public bool allowFullTopDownMovement = true;

    private Vector2 _movement;
    public Vector2 MovementInput => _movement;

    public bool PunchPressed { get; private set; }

    private float punchTimer = 0f;

    private void Update()
    {
        _movement = Vector2.zero;
        PunchPressed = false;

        if (targetPlayer == null)
            return;

        // Countdown the punch timer.
        if (punchTimer > 0f)
            punchTimer -= Time.deltaTime;

        Vector2 toPlayer = (targetPlayer.position - transform.position);
        float dist = toPlayer.magnitude;

        if (dist <= chaseRange)
        {
            if (dist <= punchRange)
            {
                // When in punching range, stop moving.
                _movement = Vector2.zero;
                if (punchTimer <= 0f)
                {
                    PunchPressed = true;
                    // Reset the punch timer to a random value between our min and max.
                    punchTimer = Random.Range(minPunchCooldown, maxPunchCooldown);
                }
            }
            else
            {
                // Otherwise, move toward the player.
                Vector2 dir = toPlayer.normalized;
                if (!allowFullTopDownMovement)
                    dir.y = 0f;
                _movement = dir;
            }
        }
        else
        {
            _movement = Vector2.zero;
        }
    }
}