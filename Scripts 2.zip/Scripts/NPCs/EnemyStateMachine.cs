using UnityEngine;

public enum EnemyCombatState
{
    Idle,
    Walking,
    Punching,
    GetHit
}

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(EnemyAIInputHandler))]
[RequireComponent(typeof(EnemyAnimationController))]
public class EnemyStateMachine : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 2f;

    [Header("Punch Settings")]
    public float punchDuration = 0.3f;

    [Header("Hit / Knockback")]
    public float knockbackForce = 2f;
    public float hitStunTime = 0.25f; // Duration for the wobbly effect
    public float invulDuration = 0.5f;

    private bool isInvulnerable = false;
    private float invulTimer = 0f;

    private Rigidbody2D rb;
    private EnemyAIInputHandler ai;
    private EnemyAnimationController anim;

    private EnemyCombatState currentState = EnemyCombatState.Idle;
    private Vector2 movement;
    private bool facingRight = true;
    // Expose a public read-only property.
    public bool IsFacingRight => facingRight;
    private float punchTimer = 0f;
    private float getHitTimer = 0f;

    [Header("References")]
    [Tooltip("Child object with PunchHitboxController.")]
    public PunchHitboxController punchHitboxPivot;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        ai = GetComponent<EnemyAIInputHandler>();
        anim = GetComponent<EnemyAnimationController>();

        rb.gravityScale = 0f;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
    }

    private void Update()
    {
        if (invulTimer > 0f)
        {
            invulTimer -= Time.deltaTime;
            if (invulTimer <= 0f)
                isInvulnerable = false;
        }

        switch (currentState)
        {
            case EnemyCombatState.Punching:
                HandlePunchState();
                break;
            case EnemyCombatState.GetHit:
                HandleGetHitState();
                break;
            default:
                HandleIdleOrWalk();
                break;
        }

        if (movement.x > 0.01f)
            facingRight = true;
        else if (movement.x < -0.01f)
            facingRight = false;

        if (punchHitboxPivot != null)
        {
            Vector3 localScale = punchHitboxPivot.transform.localScale;
            localScale.x = facingRight ? Mathf.Abs(localScale.x) : -Mathf.Abs(localScale.x);
            punchHitboxPivot.transform.localScale = localScale;
        }

        anim.UpdateAnimation(currentState, facingRight);
    }

    private void FixedUpdate()
    {
        if (currentState == EnemyCombatState.Idle || currentState == EnemyCombatState.Walking)
            rb.velocity = movement * moveSpeed;
        else
            rb.velocity = Vector2.zero;
    }

    private void HandleIdleOrWalk()
    {
        movement = ai.MovementInput;
        currentState = (movement.sqrMagnitude > 0.01f) ? EnemyCombatState.Walking : EnemyCombatState.Idle;

        if (ai.PunchPressed)
            StartPunch();
    }

    private void HandlePunchState()
    {
        punchTimer -= Time.deltaTime;
        if (punchTimer <= 0f)
            EndPunch();
    }

    private void HandleGetHitState()
    {
        getHitTimer -= Time.deltaTime;
        if (getHitTimer <= 0f)
            currentState = EnemyCombatState.Idle;
    }

    private void StartPunch()
    {
        currentState = EnemyCombatState.Punching;
        punchTimer = punchDuration;
        anim.UpdateAnimation(currentState, facingRight);
        // Hitbox activation is handled via animation events.
    }

    private void EndPunch()
    {
        OnPunchHitboxDeactivate();
        currentState = EnemyCombatState.Idle;
    }

    public void OnPunchHitboxActivate()
    {
        if (punchHitboxPivot != null)
            punchHitboxPivot.ActivateHitbox();
    }

    public void OnPunchHitboxDeactivate()
    {
        if (punchHitboxPivot != null)
            punchHitboxPivot.DeactivateHitbox();
    }

    public void TakeHit(Vector3 attackerPos, float damage)
    {
        if (currentState == EnemyCombatState.GetHit)
        {
            getHitTimer = hitStunTime;
            Debug.Log("Enemy chained hit!");
            return;
        }
        if (currentState == EnemyCombatState.Punching && punchHitboxPivot != null)
            punchHitboxPivot.DeactivateHitbox();

        currentState = EnemyCombatState.GetHit;
        getHitTimer = hitStunTime;
        isInvulnerable = true;
        invulTimer = invulDuration;

        Vector2 knockDir = (transform.position - attackerPos).normalized;
        rb.AddForce(knockDir * knockbackForce, ForceMode2D.Impulse);

        Debug.Log($"Enemy took {damage} damage!");
    }
}