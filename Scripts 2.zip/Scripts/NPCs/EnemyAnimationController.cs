using UnityEngine;

[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(SpriteRenderer))]
public class EnemyAnimationController : MonoBehaviour
{
    public string idleStateName = "Idle";
    public string walkStateName = "Walk";
    public string punchStateName = "Punch";
    public string getHitStateName = "GetHit";

    private Animator animator;
    private SpriteRenderer spriteRenderer;
    private string currentAnimation;

    private void Awake()
    {
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void UpdateAnimation(EnemyCombatState state, bool facingRight)
    {
        spriteRenderer.flipX = !facingRight;

        string animToPlay = idleStateName;
        switch (state)
        {
            case EnemyCombatState.Walking:
                animToPlay = walkStateName;
                break;
            case EnemyCombatState.Punching:
                animToPlay = punchStateName;
                break;
            case EnemyCombatState.GetHit:
                animToPlay = getHitStateName;
                break;
            default:
                animToPlay = idleStateName;
                break;
        }

        if (currentAnimation != animToPlay)
        {
            animator.Play(animToPlay);
            currentAnimation = animToPlay;
        }
    }
}