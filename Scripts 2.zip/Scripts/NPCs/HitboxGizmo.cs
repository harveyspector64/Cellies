using UnityEngine;

[ExecuteAlways]
public class HitboxGizmo : MonoBehaviour
{
    [Tooltip("Assign the collider you want to visualize. 2D only.")]
    public Collider2D targetCollider;
    [Tooltip("Color of the gizmo outline.")]
    public Color gizmoColor = Color.red;

    private void OnDrawGizmos()
    {
        if (targetCollider == null) return;

        Gizmos.color = gizmoColor;

        // Example for a CircleCollider2D
        if (targetCollider is CircleCollider2D circleCol)
        {
            Vector2 center = circleCol.bounds.center;
            float radius = circleCol.radius * Mathf.Abs(transform.lossyScale.x);
            Gizmos.DrawWireSphere(center, radius);
        }
        // Example for a BoxCollider2D
        else if (targetCollider is BoxCollider2D boxCol)
        {
            Vector2 center = boxCol.bounds.center;
            Vector2 size = boxCol.size;
            // Adjust for scale
            size.x *= Mathf.Abs(transform.lossyScale.x);
            size.y *= Mathf.Abs(transform.lossyScale.y);
            Gizmos.DrawWireCube(center, size);
        }
        // etc. for CapsuleCollider2D if needed
    }
}